import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, View } from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import { Button, ButtonGroup, withTheme, Text } from '@rneui/themed';
import Cafeh from './screens/coffee.js';
import Receita from './screens/receita.js';
import TesteApi from './screens/fetchdata.js';
import SecGrid from './screens/secgrid.js';
import Quiz from './screens/quiz.js';
import Form from './screens/form.js';
import Card from './screens/cardinterface.js';
import Fonts from './screens/fontsbasico.js';

import * as SplashScreen from 'expo-splash-screen';

const Stack = createNativeStackNavigator();


const HomeScreen = ({navigation}) => {

  const onPress = () => { navigation.navigate('Profile', {name: 'Jane'}) }

  return (
    <View style={styles.container}>
            <StatusBar style="auto" />
            <Button
              title="PROFILE"
              onPress={() => { navigation.navigate('Profile', {name: 'Jane'})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
 
            <Button
              title="CAFEH"
              onPress={() => { navigation.navigate('Cafeh', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
 
            <Button
              title="Receita"
              onPress={() => { navigation.navigate('Receita', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            /> 
            <Button
              title="Teste de Fetch"
              onPress={() => { navigation.navigate('TesteApi', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
            <Button
              title="Sec Grid"
              onPress={() => { navigation.navigate('SecGrid', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
            <Button
              title="Quiz"
              onPress={() => { navigation.navigate('Quiz', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
             <Button
              title="Form"
              onPress={() => { navigation.navigate('Form', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
            <Button
              title="Card Interface"
              onPress={() => { navigation.navigate('Card', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
            <Button
              title="Fonts Basico"
              onPress={() => { navigation.navigate('Fonts', {})}}
              icon={{
                name: 'user',
                type: 'font-awesome',
                size: 15,
                color: 'white',
              }}
              iconRight
              iconContainerStyle={{ marginLeft: 10 }}
              titleStyle={{ fontWeight: '700' }}
              buttonStyle={{
                backgroundColor: 'rgba(199, 43, 98, 1)',
                borderColor: 'transparent',
                borderWidth: 0,
                borderRadius: 30,
              }}
              containerStyle={{
                width: 280,
                marginHorizontal: 50,
                marginVertical: 10,
              }}
            />
 
    </View>
  );
}

const ProfileScreen = ({navigation, route}) => {
  //chaves do .env
  const apiUrl = process.env.EXPO_PUBLIC_API_URL;
  const apiKey = process.env.EXPO_PUBLIC_API_KEY;

  return (      
    <View style={styles.container}>        
        <Text>{apiUrl}</Text>
        <Text>{apiKey}</Text>
        <Text>This is {route.params.name}'s profile</Text>
    </View>
);
}


const App = () => {


    SplashScreen.preventAutoHideAsync();
    setTimeout(SplashScreen.hideAsync, 5000); return (

    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{title: 'Welcome'}}
        />
        <Stack.Screen
          name="Cafeh"
          component={Cafeh}
          options={{title: 'Vennhaaa'}}
        />
        <Stack.Screen
          name="Receita"
          component={Receita}
          options={{title: 'Modelo de Receita'}}
        />
        <Stack.Screen
          name="TesteApi"
          component={TesteApi}
          options={{title: 'Modelo de Consumo de API'}}
        />
        <Stack.Screen
          name="SecGrid"
          component={SecGrid}
          options={{title: 'Teste de Grid'}}
        />
        <Stack.Screen
          name="Quiz"
          component={Quiz}
          options={{title: 'Quiz Basico'}}
        />
        <Stack.Screen
          name="Form"
          component={Form}
          options={{title: 'Form Basico'}}
        />
        <Stack.Screen
          name="Card"
          component={Card}
          options={{title: 'Card Interface'}}
        />
        <Stack.Screen
          name="Fonts"
          component={Fonts}
          options={{title: 'Fonts Basico'}}
        />

        <Stack.Screen name="Profile" component={ProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  item: {
    backgroundColor: '#ffffff',
    padding: 3,
    borderRadius: 12,
    borderStyle:"solid",
    borderWidth: 1,
    borderColor: "bleck",
    marginVertical: 10,
    marginHorizontal: 12,
  },
});

export default withTheme(App, '');
